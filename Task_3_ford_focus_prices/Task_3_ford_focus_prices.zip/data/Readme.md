# Origin of data

The data of used Ford Focus Hatchbacks was scraped from the largest Hungarian used car website, hasznaltauto.hu on 2020.10.13 15:32 for education and research purposes as part of a University course term project. 

For the data collection I used a publicly available point and click interface web scraper which can be added as an extension to Google Chrome at the following website (<https://webscraper.io/>). 

The raw, scraped data can be found in the raw folder. 
In the clean folder the filtered and cleaned dataset can be found ready for analysis.
The clean folder contains a dataset for Honda Civic cars as well for external validity and generalization test.

The Variables.xlsx contains the variables description of the cleaned dataset.