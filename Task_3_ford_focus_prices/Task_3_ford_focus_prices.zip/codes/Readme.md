# Properties of codes folder

In the codes folder 2 R script files and an R-markdown file can be found.

The clean_focus_data.R cleans and filters the dataset to its final form for the analysis.

The analysis_focus_data.R conducts a prediction analysis using multiple linear regression.

The AS_Term_Project_ford_focus.Rmd creates the final report from the analysis.