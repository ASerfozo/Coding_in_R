# This folder contains the coding 1 covid assignment of Attila Serfozo for CEU Business Analytics Data Analysis and Coding in R classes.

In the folder there are 4 subfolders. 
- In the codes folder there are the R files for data download, data cleaning and analysis and reporting.
- In the data folder the raw and clean datatables can be found.
- In the docs folder the reports are located in html and pdf format.
- In the out folder the outputs of the models are located like the model comparison table of the analysis.

The projects github repo link: https://github.com/ASerfozo/Coding_in_R/tree/main/Task_2_covid_cases
