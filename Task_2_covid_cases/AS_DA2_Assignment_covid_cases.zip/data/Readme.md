# Origin of data

The 2019 population data is collected from World Development Indicators (WDI) maintained by World Bank and can be found in the raw folder.

The COVID-19 cases data is collected by the Center for Systems Science and Engineering (CSSE) at Johns Hopkins University and includes the information about the covid cases until the date of 17.10.2020. It is in the raw folder.

In the clean folder the combine of these datasets can be found filtered and joined for the analysis.
