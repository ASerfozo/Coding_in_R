# Origin of data

The data of Rome Airbnbs was downloaded from insideairbnb.com refering to the airbnbs available on 2019.10.16. 

The raw, downloaded data can be found in the raw folder. It is in a compressed zip folder as it's large size didn't allow direct upload to github. The folder also includes a pre-cleaned version of the original data as well with reduced size.

In the clean folder the cleaned dataset can be found ready for analysis.